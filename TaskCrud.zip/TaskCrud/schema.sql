drop table if exists project;
	create table project (
		id integer primary key autoincrement,
		content text not null,
		done boolean
	);
	
